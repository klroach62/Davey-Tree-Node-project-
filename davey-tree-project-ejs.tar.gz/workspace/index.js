exports.index = function(req,res)
{
    var treesDao = require('../dao/dupTrees.js');
    treesDao.treesDao.getDupTrees( function (trees)
    {
        console.log(trees);
        res.render('TreeListMain' , {
            trees : trees
        });
    });
};

