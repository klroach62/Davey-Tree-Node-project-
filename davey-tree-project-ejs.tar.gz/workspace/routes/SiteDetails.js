var connProvider = require("../dao/mySqlConnectionP");
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
    var getTrees = require('../dao/dupTrees.js');
    
    getTrees.getSite1(req.query.id, function(TreeAddress) {
        res.render('SiteDetails' , {
            TreeAddress : TreeAddress 
        });
    });
    
    
});


module.exports = router;
