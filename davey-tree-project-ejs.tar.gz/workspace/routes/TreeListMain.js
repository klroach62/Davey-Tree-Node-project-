var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/TreeListMain', function(req, res, next) { 

    var getTrees = require('../dao/dupTrees.js');
    getTrees.getSites( function (TreeAddress) 
    {
        res.render('TreeListMain' , {
            TreeAddress : TreeAddress
        });
    });
    
});


module.exports = router;
