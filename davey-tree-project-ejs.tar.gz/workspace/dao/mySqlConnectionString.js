
//  host: "davey-tree-project-klroach62.c9users.io",
var mySqlConnectionString = {
 
    connectionString : {
        dev : {    
            host: "0.0.0.0",
            user: "klroach62",
            password: "",
            database: "c9"
        },
        prod : {    
            host: "0.0.0.0",
            user: "klroach62",
            password: "",
            database: "c9"
        }
    }

};
exports. mySqlConnectionString =  mySqlConnectionString;
