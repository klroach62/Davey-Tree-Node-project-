var mysql = require("mysql");
var mysqlCS = require('./mySqlConnectionString.js');
var mysqlConnectionP = 
{
    getSqlConn : function()
    {
        var conn = mysql.createConnection(mysqlCS.mySqlConnectionString.connectionString.dev);
        conn.connect(function(error)
        {
            if(error) throw error;
            console.log("connected to Database");
            
        });
        return conn;
    },
    closeConn : function(currentConn) {
        currentConn.end( function(error)
        {
            if(error) throw error;
            console.log("disconnected from Database");
            
        });
//        return currentConn;
    }
    
    
};

exports.mysqlConnectionP = mysqlConnectionP;