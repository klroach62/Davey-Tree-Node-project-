var connProvider = require("./mySqlConnectionP");

    var getSite1 = function(myid,callback)
    {
        var TreeAddress = []; 
        var connection = connProvider.mysqlConnectionP.getSqlConn();
        var sql = 'SELECT * FROM trees where id='+myid;
        
        if(connection)
         {
             connection.query(sql, function(err, rows, fields) {
                    rows.forEach(function (row) {
                    TreeAddress.push(row);
                 });
                 callback(TreeAddress);
                 });
        }
        connProvider.mysqlConnectionP.closeConn(connection);
    };
        var getSites = function(callback)
    {
        var TreeAddress = []; 
        var connection = connProvider.mysqlConnectionP.getSqlConn();
        var sql = 'SELECT * FROM trees';
        
        if(connection)
         {
             connection.query(sql, function(err, rows) {
                    rows.forEach(function (row) {
                    TreeAddress.push(row);
                 });
                        callback(TreeAddress);
             });
        }
        connProvider.mysqlConnectionP.closeConn(connection);
    };
    
    var getDupSites = function(callback)
    {
        var TreeAddress = []; 
        var connection = connProvider.mysqlConnectionP.getSqlConn();
        var sql = 'SELECT distinct a.* FROM trees a INNER JOIN trees b ON a.address = b.address and a.Street=b.Street and a.site = b.site WHERE a.id <> b.id';
        if(connection)
         {
             connection.query(sql, function(err, rows, fields) {
                    rows.forEach(function (row) {
                    TreeAddress.push(row);
                 });
                 callback(TreeAddress);
             });
        }
        connProvider.mysqlConnectionP.closeConn(connection);
    };
    var updateSite = function(id,PASSbody,res)
    {
        var connection = connProvider.mysqlConnectionP.getSqlConn();
        var body = JSON.parse(PASSbody);
        if(connection)
         {
            var query = connection.query("UPDATE trees SET Address = ?, Street = ?, Side = ?, Site = ?, Species = ?, `Condition` = ?, DBH = ? WHERE id = ?", [body.Address, body.Street, body.Side, body.Site, body.Species, body.Condition, body.DBH, id]);
         };
        connProvider.mysqlConnectionP.closeConn(connection);
    };


module.exports = {
    getSite1: getSite1,
    getSites: getSites,
    getDupSites: getDupSites,
    updateSite: updateSite
    };